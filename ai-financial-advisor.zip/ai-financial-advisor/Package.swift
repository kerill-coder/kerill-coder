// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "FinancialAdvisorCore",
    platforms: [
        .iOS(.v16)
    ],
    products: [
        .library(name: "FinancialAdvisorCore", targets: ["Core"])
    ],
    dependencies: [
        // Можно добавить Swift AI libs, если нужно
    ],
    targets: [
        .target(name: "Core", dependencies: []),
        .testTarget(name: "CoreTests", dependencies: ["Core"]),
    ]
)
